﻿using System;

namespace LibraryWithArrays
{
    class Program
    {

        static void Main(string[] args)
        {
        }
    }
}
