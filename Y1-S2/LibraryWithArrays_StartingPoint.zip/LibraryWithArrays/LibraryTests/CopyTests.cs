using LibraryWithArrays;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace LibraryTests
{
    [TestClass]
    public class CopyTests
    {
        //[TestMethod]
        //public void Test_ExpectCopyAvailableStateValueIsCorrect()
        //{
        //    Assert.AreEqual("Available", Copy.AVAILABLE_STATE);
        //}

        //[TestMethod]
        //public void Test_ExpectCopyOnLoanStateValueIsCorrect()
        //{
        //    Assert.AreEqual("On loan", Copy.ON_LOAN_STATE);
        //}

        //[TestMethod]
        //public void Test_WhenCopyIsCreated_ExpectStateIsAvailable()
        //{
        //    Book b = new Book("", "", "");
        //    Copy c = new Copy(b);

        //    Assert.AreEqual(Copy.AVAILABLE_STATE, c.State);
        //}

        //[TestMethod]
        //public void Test_WhenCopyIsCreated_ExpectCopysBookIsCorrect()
        //{
        //    Book b = new Book("", "", "");
        //    Copy c = new Copy(b);

        //    Assert.AreEqual(b, c.Book);
        //}

        //[TestMethod]
        //public void Test_WhenCopyIsCreated_ExpectCopyIsAddedToBook()
        //{
        //    Book b = new Book("", "", "");
        //    Copy c = new Copy(b);

        //    Assert.AreEqual(c, b.GetCopies()[0]);
        //}

        //[TestMethod]
        //public void Test_WhenTwoConsecutiveCopiesAreCreated_ExpectTheIdOfTheSecondCopyIsOneMoreThanTheIdOfTheFirst()
        //{
        //    Book b = new Book("", "", "");
        //    Copy c1 = new Copy(b);
        //    Copy c2 = new Copy(b);

        //    Assert.AreEqual(c1.Id + 1, c2.Id);
        //}
    }
}
